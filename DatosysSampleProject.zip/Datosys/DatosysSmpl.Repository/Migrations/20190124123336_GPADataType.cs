﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DatosysSmpl.Repository.Migrations
{
    public partial class GPADataType : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<double>(
                name: "GPA",
                table: "CourseStudents",
                nullable: false,
                oldClrType: typeof(decimal));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<decimal>(
                name: "GPA",
                table: "CourseStudents",
                nullable: false,
                oldClrType: typeof(double));
        }
    }
}
