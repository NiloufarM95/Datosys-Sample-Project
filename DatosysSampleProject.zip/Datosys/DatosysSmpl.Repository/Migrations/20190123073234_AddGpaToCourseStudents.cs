﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DatosysSmpl.Repository.Migrations
{
    public partial class AddGpaToCourseStudents : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<decimal>(
                name: "GPA",
                table: "CourseStudents",
                nullable: false,
                defaultValue: 0m);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "GPA",
                table: "CourseStudents");
        }
    }
}
