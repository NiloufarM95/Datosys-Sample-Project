﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using DatosysSmpl.Data.Entities;
using DatosysSmpl.Data.Maps;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace DatosysSmpl.Repository
{
    public class ApplicationContext:DbContext
    {
        public ApplicationContext(DbContextOptions<ApplicationContext> options) : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            new RoleMap(modelBuilder.Entity<Role>());
            new PersonMap(modelBuilder.Entity<Person>());
            new CourseMap(modelBuilder.Entity<Course>());
            new CourseStudentsMap(modelBuilder.Entity<CourseStudents>());

            foreach (var relationship in modelBuilder.Model.GetEntityTypes().SelectMany(e => e.GetForeignKeys()))
            {
                relationship.DeleteBehavior = DeleteBehavior.Restrict;
            }
        }

        public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<ApplicationContext>
        {
            public ApplicationContext CreateDbContext(string[] args)
            {
                var configuration = new ConfigurationBuilder()
                    .SetBasePath(Directory.GetCurrentDirectory().Replace("Repository", "Web"))
                    .AddJsonFile("appsettings.Development.json")
                    .Build();

                var builder = new DbContextOptionsBuilder<ApplicationContext>();

                var connectionString = configuration.GetConnectionString("DefaultConnection");

                builder.UseSqlServer(connectionString);

                return new ApplicationContext(builder.Options);
            }

        }
    }
}
