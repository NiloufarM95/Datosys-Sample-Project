﻿using System;
using System.Collections.Generic;
using System.Text;
using DatosysSmpl.Data.Entities;
using DatosysSmpl.Repository.Abstract;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace DatosysSmpl.Repository.Concrete
{
    public class PersonRepository : Repository<Person>, IPersonRepository
    {
        private readonly DbSet<Person> _entity;
        public PersonRepository(ILogger<Person> logger, ApplicationContext context) : base(logger, context)
        {
            _entity = context.Set<Person>();
        }

    }
}
