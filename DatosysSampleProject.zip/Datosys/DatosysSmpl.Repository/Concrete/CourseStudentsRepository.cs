﻿using System;
using System.Collections.Generic;
using System.Text;
using DatosysSmpl.Data.Entities;
using DatosysSmpl.Repository.Abstract;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace DatosysSmpl.Repository.Concrete
{
    public class CourseStudentsRepository : Repository<CourseStudents>, ICourseStudentsRepository
    {
        private readonly DbSet<CourseStudents> _entity;
        public CourseStudentsRepository(ILogger<CourseStudents> logger, ApplicationContext context) : base(logger, context)
        {
            _entity = context.Set<CourseStudents>();
        }

    }
}
