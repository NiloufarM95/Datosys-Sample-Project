﻿using System;
using System.Collections.Generic;
using System.Text;
using DatosysSmpl.Data.Entities;
using DatosysSmpl.Repository.Abstract;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace DatosysSmpl.Repository.Concrete
{
    public class RoleRepository : Repository<Role>, IRoleRepository
    {
        private readonly DbSet<Role> _entity;
        public RoleRepository(ILogger<Role> logger, ApplicationContext context) : base(logger, context)
        {
            _entity = context.Set<Role>();
        }

    }
}
