﻿using System;
using System.Collections.Generic;
using System.Text;
using DatosysSmpl.Data.Entities;
using DatosysSmpl.Repository.Abstract;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace DatosysSmpl.Repository.Concrete
{
    public class CourseRepository : Repository<Course>, ICourseRepository
    {
        private readonly DbSet<Course> _entity;
        public CourseRepository(ILogger<Course> logger, ApplicationContext context) : base(logger, context)
        {
            _entity = context.Set<Course>();
        }

    }
}
