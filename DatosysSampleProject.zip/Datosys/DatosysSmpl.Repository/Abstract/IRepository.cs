﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using DatosysSmpl.Data.Entities;

namespace DatosysSmpl.Repository.Abstract
{
    public interface IRepository<T> where T:BaseEntity
    {
        /// <summary>
        /// Returns all existing items of an entity
        /// </summary>
        /// <returns></returns>
        IQueryable<T> GetAll();

        /// <summary>
        /// Returns all existing items of an entity by an expression
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>
        IQueryable<T> GetBy(Expression<Func<T, bool>> predicate);

        /// <summary>
        /// Returns an item of an entity by its Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        T Get(long id);

        /// <summary>
        /// Insert a new item
        /// </summary>
        /// <param name="entity"></param>
        void Insert(T entity);

        /// <summary>
        /// Update an item
        /// </summary>
        /// <param name="entity"></param>
        void Update(T entity);

        /// <summary>
        /// Delete an item by its Id
        /// </summary>
        /// <param name="id"></param>
        void Delete(long id);

        /// <summary>
        /// Save any change in database
        /// </summary>
        void SaveChanges();
    }
}
