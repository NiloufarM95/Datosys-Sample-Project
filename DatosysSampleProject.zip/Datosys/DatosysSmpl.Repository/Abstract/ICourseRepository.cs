﻿using System;
using System.Collections.Generic;
using System.Text;
using DatosysSmpl.Data.Entities;

namespace DatosysSmpl.Repository.Abstract
{
    public interface ICourseRepository : IRepository<Course>
    {

    }
}
