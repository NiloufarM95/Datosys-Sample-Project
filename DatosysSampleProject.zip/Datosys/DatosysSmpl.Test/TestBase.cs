﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Claims;
using System.Text;
using DatosysSmpl.Service;
using DatosysSmpl.Web.Controllers;
using DatosysSmpl.Web.Service;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestPlatform.TestHost;
using Moq;

namespace DatosysSmpl.Test
{
    public class Startup
    {
        public Startup(IHostingEnvironment env, IConfiguration configuration)
        {

            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", false, true)
                .AddEnvironmentVariables();
            Configuration = builder.Build();
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {

            DI.ConfigureServices(services, Configuration.GetConnectionString("DefaultConnection"));
        }

        public void Configure(IApplicationBuilder app)
        {
        }
    }
    public class TestBase
    {
        public IWebHost Host { get; set; }
        public string[] Args { get; set; }
        public IServiceScope Scope { get; set; }
        public IServiceProvider Services { get; set; }
        public bool Status { get; set; }
        public static IConfiguration Configuration { get; set; }
        public TestBase()
        {
            Host = BuildWebHost(Args);
            Scope = Host.Services.CreateScope();
            Services = Scope.ServiceProvider;
            Status = true;
            Configuration = InitConfiguration();
        }
        public static IWebHost BuildWebHost(string[] args)
        {
            return WebHost.CreateDefaultBuilder(args)
                .UseUrls("http://localhost")
                .UseStartup<Startup>()
                .Build();
        }

        public static IConfiguration InitConfiguration()
        {
            var config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build();
            return config;
        }
        public BaseController GetBaseController()
        {
            var roleService = Services.GetService<IRoleService>();
            var personService = Services.GetService<IPersonService>();
            var courseService = Services.GetService<ICourseService>();
            var courseStudentsService = Services.GetService<ICourseStudentsService>();

            var controller = new BaseController(roleService, personService, courseService, courseStudentsService
                );

            return controller;
        }
        public BaseController GetBaseControllerMock<T>(Func<Mock<T>> initMock) where T : class
        {
            var roleService = typeof(T) == typeof(IRoleService) ? (IRoleService)initMock().Object : null;
            var personService = typeof(T) == typeof(IPersonService) ? (IPersonService)initMock().Object : null;
            var courseService = typeof(T) == typeof(ICourseService) ? (ICourseService)initMock().Object : null;
            var courseStudentsService = typeof(T) == typeof(ICourseStudentsService) ? (ICourseStudentsService)initMock().Object : null;

            var controller = new BaseController(roleService, personService, courseService, courseStudentsService
               );
            return controller;
        }
    }
}
