﻿using System;
using System.Collections.Generic;
using System.Text;
using DatosysSmpl.Data.Entities;
using DatosysSmpl.Repository.Abstract;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace DatosysSmpl.Test
{
    public class BaseInfoMockTest : TestBase
    {
        [Fact(Skip = "For Init Only ")]
        //[Fact]
        public void InitDatabase()
        {
            try
            {
                var applicationContext = Services.GetRequiredService<Repository.ApplicationContext>();

                applicationContext.Database.EnsureDeleted();
                applicationContext.Database.Migrate();

                DefaultRole();
            }

            catch (Exception ex)
            {
                Status = false;
                Assert.True(Status);
            }
        }

        private void DefaultRole()
        {
            var data1 = new Role()
            {
                ModifiedDate = DateTime.Now,
                AddedDate = DateTime.Now.AddHours(-2),
                RoleName = "Teacher",

            };
            var data2 = new Role()
            {
                ModifiedDate = DateTime.Now,
                AddedDate = DateTime.Now.AddHours(-2),
                RoleName = "Student",

            };
            try
            {

                var service = Services.GetRequiredService<IRoleRepository>();
                service.Insert(data1);
                service.Insert(data2);

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
