﻿using DatosysSmpl.Web.Controllers;
using DatosysSmpl.Web.Models;
using DatosysSmpl.Web.Service;
using System;
using System.Collections.Generic;
using Microsoft.Extensions.DependencyInjection;
using System.Text;
using Mapster;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace DatosysSmpl.Test.DatosysMockTests
{
    public class CourseStudentsTests : TestBase
    {
        private BaseController _controller;
        private ICourseStudentsService _service;
        private CourseStudentsViewModel courseStudentsViewModel;
        public CourseStudentsTests()
        {
            _service = Services.GetService<ICourseStudentsService>();

            courseStudentsViewModel = new CourseStudentsViewModel
            {
                Id = 1000,
                StudentId = 1,
                CourseId = 1
            };
        }
        [Fact]
        public void CreateActionReturnsCreateView()
        {
            _controller = GetBaseController();
            var result = _controller.CourseStudentsCreate(courseStudentsViewModel.CourseId);
            var viewResult = Assert.IsType<ViewResult>(result);

            Assert.Equal("CourseStudentsCreate", viewResult.ViewName);
        }


        [Fact]
        public void TestEditViewData()
        {
            _controller = GetBaseControllerMock(InitMockForEdit);
            var data = _controller.CourseStudentsEdit(courseStudentsViewModel.Id, courseStudentsViewModel.CourseId) as ViewResult;
            var result = (CourseStudentsViewModel)data.Model;

            Assert.Equal(1, result.CourseId);
            Assert.Equal(1, result.StudentId);
        }

        [Fact]
        public void CreateActionPostMethod()
        {
            _controller = GetBaseControllerMock(InitMockForCreate);
            var result = _controller.CourseStudentsCreate(courseStudentsViewModel);
            var viewResult = Assert.IsType<RedirectToActionResult>(result);

            Assert.Equal("CourseStudents", viewResult.ActionName);
        }

        [Fact]
        public void IndexActionReturnsCourseStudentsList()
        {
            _controller = GetBaseControllerMock(InitMockForList);
            var result = _controller.CourseStudents(courseStudentsViewModel.CourseId);
            var viewResult = Assert.IsType<ViewResult>(result);
            var data = viewResult;
            var res = (CourseStudentsPageViewModel)data.Model;

            Assert.NotNull(res);
            Assert.Equal(4, res.CourseStudents.Count);
        }

        [Fact]
        public void DeleteActionReturnsIndexViewIfDeleted()
        {
            _controller = GetBaseControllerMock(InitMockForDelete);
            var result = _controller.CourseStudentsDelete(courseStudentsViewModel.Id, courseStudentsViewModel.CourseId);
            var viewResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("CourseStudents", viewResult.ActionName);
        }

        [Fact]
        public void CrudFullTest()
        {
            ////ListPage
            IndexActionReturnsCourseStudentsList();

            //////Create New 
            CreateActionReturnsCreateView();

            //////Post Create New
            CreateActionPostMethod();

            ////CourseStudentsEdit Load
            TestEditViewData();

            ////Post CourseStudentsDelete
            DeleteActionReturnsIndexViewIfDeleted();
        }

        private CourseStudentsPageViewModel GetList()
        {
            var list = new List<CourseStudentsViewModel>
            {
                new CourseStudentsViewModel
                {
                    Id = 1000,
                    StudentId = 1,
                    CourseId = 1
                },
                new CourseStudentsViewModel
                {
                    Id = 1002,
                    StudentId = 2,
                    CourseId = 1
                },
                new CourseStudentsViewModel
                {
                    Id = 1003,
                    StudentId = 1,
                    CourseId = 2
                },
                new CourseStudentsViewModel
                {
                    Id = 1004,
                    StudentId = 2,
                    CourseId = 2
                }
            };
            return new CourseStudentsPageViewModel
            {
                CourseStudents = list,
                CourseStudent = new CourseStudentsViewModel()
            };
        }


        private Mock<ICourseStudentsService> InitMockForEdit()
        {
            var mock = new Mock<ICourseStudentsService>();
            mock.Setup(x => x.GetCourseStudent(courseStudentsViewModel.Id, courseStudentsViewModel.CourseId))
                .Returns(new CourseStudentsViewModel
                {
                    Id = 1000,
                    StudentId = 1,
                    CourseId = 1
                });
            return mock;
        }
        private Mock<ICourseStudentsService> InitMockForCreate()
        {
            var mock = new Mock<ICourseStudentsService>();
            mock.Setup(x => x.Insert(courseStudentsViewModel.Adapt(new CourseStudentsViewModel())));
            return mock;
        }
        private Mock<ICourseStudentsService> InitMockForDelete()
        {
            var mock = new Mock<ICourseStudentsService>();
            mock.Setup(x => x.Delete(courseStudentsViewModel.Id));
            return mock;
        }

        private Mock<ICourseStudentsService> InitMockForList()
        {
            var list = GetList();
            var mock = new Mock<ICourseStudentsService>();
            mock
                .Setup(x => x.GetAllCourses(courseStudentsViewModel.CourseId))
                .Returns(list);
            return mock;
        }
    }
}
