﻿using DatosysSmpl.Web.Controllers;
using DatosysSmpl.Web.Models;
using DatosysSmpl.Web.Service;
using System;
using System.Collections.Generic;
using Microsoft.Extensions.DependencyInjection;
using System.Text;
using Mapster;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace DatosysSmpl.Test.DatosysMockTests
{
    public class PersonTests : TestBase
    {
        private BaseController _controller;
        private IPersonService _service;
        private PersonViewModel personViewModel;
        public PersonTests()
        {
            _service = Services.GetService<IPersonService>();

            personViewModel = new PersonViewModel
            {
                Id = 1000,
                FirstName = "test",
                LastName = "test",
                RoleId = 1
            };
        }
        [Fact]
        public void CreateActionReturnsCreateView()
        {
            _controller = GetBaseController();
            var result = _controller.PersonCreate();
            var viewResult = Assert.IsType<ViewResult>(result);

            Assert.Equal("PersonCreate", viewResult.ViewName);
        }


        [Fact]
        public void TestEditViewData()
        {
            _controller = GetBaseControllerMock(InitMockForEdit);
            var data = _controller.PersonEdit(1000) as ViewResult;
            var result = (PersonViewModel)data.Model;

            Assert.Equal("test", result.FirstName);
            Assert.Equal(1, result.RoleId);
        }

        [Fact]
        public void CreateActionPostMethod()
        {
            _controller = GetBaseControllerMock(InitMockForCreate);
            var result = _controller.PersonCreate(personViewModel);
            var viewResult = Assert.IsType<RedirectToActionResult>(result);

            Assert.Equal("Person", viewResult.ActionName);
        }

        [Fact]
        public void IndexActionReturnsPersonList()
        {
            _controller = GetBaseControllerMock(InitMockForList);
            var result = _controller.Person();
            var viewResult = Assert.IsType<ViewResult>(result);
            var data = viewResult;
            var res = (List<PersonViewModel>)data.Model;

            Assert.NotNull(res);
            Assert.Equal(4, res.Count);
        }

        [Fact]
        public void DeleteActionReturnsIndexViewIfDeleted()
        {
            _controller = GetBaseControllerMock(InitMockForDelete);
            var result = _controller.PersonDelete(10000);
            var viewResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Person", viewResult.ActionName);
        }

        [Fact]
        public void CrudFullTest()
        {
            ////ListPage
            IndexActionReturnsPersonList();

            //////Create New 
            CreateActionReturnsCreateView();

            //////Post Create New
            CreateActionPostMethod();

            ////PersonEdit Load
            TestEditViewData();

            ////Post PersonDelete
            DeleteActionReturnsIndexViewIfDeleted();
        }

        private List<PersonViewModel> GetList()
        {
            var list = new List<PersonViewModel>
            {
                new PersonViewModel
                {
                    Id = 1000,
                    FirstName = "test1",
                    LastName = "test1",
                    RoleId = 1
                },
                new PersonViewModel
                {
                    Id = 1001,
                    FirstName = "test2",
                    LastName = "test2",
                    RoleId = 1
                },
                new PersonViewModel
                {
                    Id = 1002,
                    FirstName = "test3",
                    LastName = "test3",
                    RoleId = 2
                },
                new PersonViewModel
                {
                    Id = 1003,
                    FirstName = "test4",
                    LastName = "test4",
                    RoleId = 2
                }
            };
            return list;
        }


        private Mock<IPersonService> InitMockForEdit()
        {
            var mock = new Mock<IPersonService>();
            mock.Setup(x => x.Get(1000))
                .Returns(new PersonViewModel
                {
                    Id = 1000,
                    FirstName = "test",
                    LastName = "test",
                    RoleId = 1
                });
            return mock;
        }
        private Mock<IPersonService> InitMockForCreate()
        {
            var mock = new Mock<IPersonService>();
            mock.Setup(x => x.Insert(personViewModel.Adapt(new PersonViewModel())));
            return mock;
        }
        private Mock<IPersonService> InitMockForDelete()
        {
            var mock = new Mock<IPersonService>();
            mock.Setup(x => x.Delete(10000));
            return mock;
        }

        private Mock<IPersonService> InitMockForList()
        {
            var list = GetList();
            var mock = new Mock<IPersonService>();
            mock
                .Setup(x => x.GetAll())
                .Returns(list);
            return mock;
        }
    }
}
