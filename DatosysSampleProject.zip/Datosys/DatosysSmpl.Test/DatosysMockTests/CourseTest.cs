﻿using DatosysSmpl.Web.Controllers;
using DatosysSmpl.Web.Models;
using DatosysSmpl.Web.Service;
using System;
using System.Collections.Generic;
using Microsoft.Extensions.DependencyInjection;
using System.Text;
using Mapster;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace DatosysSmpl.Test.DatosysMockTests
{
    public class CourseTests : TestBase
    {
        private BaseController _controller;
        private ICourseService _service;
        private CourseViewModel courseViewModel;
        public CourseTests()
        {
            _service = Services.GetService<ICourseService>();

            courseViewModel = new CourseViewModel
            {
                Id = 1000,
                TeacherId = 1,
                ClassName = "test"
            };
        }
        [Fact]
        public void CreateActionReturnsCreateView()
        {
            _controller = GetBaseController();
            var result = _controller.CourseCreate();
            var viewResult = Assert.IsType<ViewResult>(result);

            Assert.Equal("CourseCreate", viewResult.ViewName);
        }


        [Fact]
        public void TestEditViewData()
        {
            _controller = GetBaseControllerMock(InitMockForEdit);
            var data = _controller.CourseEdit(1000) as ViewResult;
            var result = (CourseViewModel)data.Model;

            Assert.Equal("test", result.ClassName);
            Assert.Equal(1, result.TeacherId);
        }

        [Fact]
        public void CreateActionPostMethod()
        {
            _controller = GetBaseControllerMock(InitMockForCreate);
            var result = _controller.CourseCreate(courseViewModel);
            var viewResult = Assert.IsType<RedirectToActionResult>(result);

            Assert.Equal("Course", viewResult.ActionName);
        }

        [Fact]
        public void IndexActionReturnsCourseList()
        {
            _controller = GetBaseControllerMock(InitMockForList);
            var result = _controller.Course();
            var viewResult = Assert.IsType<ViewResult>(result);
            var data = viewResult;
            var res = (List<CourseViewModel>)data.Model;

            Assert.NotNull(res);
            Assert.Equal(4, res.Count);
        }

        [Fact]
        public void DeleteActionReturnsIndexViewIfDeleted()
        {
            _controller = GetBaseControllerMock(InitMockForDelete);
            var result = _controller.CourseDelete(10000);
            var viewResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Course", viewResult.ActionName);
        }

        [Fact]
        public void CrudFullTest()
        {
            ////ListPage
            IndexActionReturnsCourseList();

            //////Create New 
            CreateActionReturnsCreateView();

            //////Post Create New
            CreateActionPostMethod();

            ////CourseEdit Load
            TestEditViewData();

            ////Post CourseDelete
            DeleteActionReturnsIndexViewIfDeleted();
        }

        private List<CourseViewModel> GetList()
        {
            var list = new List<CourseViewModel>
            {
                new CourseViewModel
                {
                    Id = 1001,
                    TeacherId = 1,
                    ClassName = "test1"
                },
                new CourseViewModel
                {
                    Id = 1002,
                    TeacherId = 2,
                    ClassName = "test2"
                },
                new CourseViewModel
                {
                    Id = 1003,
                    TeacherId = 1,
                    ClassName = "test3"
                },
                new CourseViewModel
                {
                    Id = 1004,
                    TeacherId = 2,
                    ClassName = "test4"
                }
            };
            return list;
        }


        private Mock<ICourseService> InitMockForEdit()
        {
            var mock = new Mock<ICourseService>();
            mock.Setup(x => x.Get(1000))
                .Returns(new CourseViewModel
                {
                    Id = 1000,
                    TeacherId = 1,
                    ClassName = "test"
                });
            return mock;
        }
        private Mock<ICourseService> InitMockForCreate()
        {
            var mock = new Mock<ICourseService>();
            mock.Setup(x => x.Insert(courseViewModel.Adapt(new CourseViewModel())));
            return mock;
        }
        private Mock<ICourseService> InitMockForDelete()
        {
            var mock = new Mock<ICourseService>();
            mock.Setup(x => x.Delete(10000));
            return mock;
        }

        private Mock<ICourseService> InitMockForList()
        {
            var list = GetList();
            var mock = new Mock<ICourseService>();
            mock
                .Setup(x => x.GetAll())
                .Returns(list);
            return mock;
        }
    }
}
