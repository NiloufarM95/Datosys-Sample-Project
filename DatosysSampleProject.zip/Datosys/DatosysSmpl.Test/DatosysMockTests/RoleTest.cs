﻿using DatosysSmpl.Web.Controllers;
using DatosysSmpl.Web.Models;
using DatosysSmpl.Web.Service;
using System;
using System.Collections.Generic;
using Microsoft.Extensions.DependencyInjection;
using System.Text;
using Mapster;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace DatosysSmpl.Test.DatosysMockTests
{
    public class RoleTests : TestBase
    {
        private BaseController _controller;
        private IRoleService _service;
        private RoleViewModel roleViewModel;
        public RoleTests()
        {
            _service = Services.GetService<IRoleService>();

            roleViewModel = new RoleViewModel
            {
                Id = 1000,
                RoleName = "TestRole"

            };
        }
        [Fact]
        public void CreateActionReturnsCreateView()
        {
            _controller = GetBaseController();
            var result = _controller.RoleCreate();
            var viewResult = Assert.IsType<ViewResult>(result);

            Assert.Equal("RoleCreate", viewResult.ViewName);
        }


        [Fact]
        public void TestEditViewData()
        {
            _controller = GetBaseControllerMock(InitMockForEdit);
            var data = _controller.RoleEdit(1000) as ViewResult;
            var result = (RoleViewModel)data.Model;

            Assert.Equal("RoleTest", result.RoleName);
        }

        [Fact]
        public void CreateActionPostMethod()
        {
            _controller = GetBaseControllerMock(InitMockForCreate);
            var result = _controller.RoleCreate(roleViewModel);
            var viewResult = Assert.IsType<RedirectToActionResult>(result);

            Assert.Equal("Role", viewResult.ActionName);
        }

        [Fact]
        public void IndexActionReturnsRoleList()
        {
            _controller = GetBaseControllerMock(InitMockForList);
            var result = _controller.Role();
            var viewResult = Assert.IsType<ViewResult>(result);
            var data = viewResult;
            var res = (List<RoleViewModel>)data.Model;

            Assert.NotNull(res);
            Assert.Equal(4, res.Count);
        }

        [Fact]
        public void DeleteActionReturnsIndexViewIfDeleted()
        {
            _controller = GetBaseControllerMock(InitMockForDelete);
            var result = _controller.RoleDelete(10000);
            var viewResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Role", viewResult.ActionName);
        }

        [Fact]
        public void CrudFullTest()
        {
            ////ListPage
            IndexActionReturnsRoleList();

            //////Create New 
            CreateActionReturnsCreateView();

            //////Post Create New
            CreateActionPostMethod();

            ////RoleEdit Load
            TestEditViewData();

            ////Post RoleDelete
            DeleteActionReturnsIndexViewIfDeleted();
        }

        private List<RoleViewModel> GetList()
        {
            var list = new List<RoleViewModel>
            {
                new RoleViewModel
                {
                     RoleName = "Role1",
                },
                new RoleViewModel
                {
                    RoleName = "Role2",
                },
                new RoleViewModel
                {
                    RoleName = "Role3",
                },
                new RoleViewModel
                {
                    RoleName = "Role4",
                }
            };
            return list;
        }


        private Mock<IRoleService> InitMockForEdit()
        {
            var mock = new Mock<IRoleService>();
            mock.Setup(x => x.Get(1000))
                .Returns(new RoleViewModel
                {
                    Id = 1000,
                    RoleName = "RoleTest",
                    AddedDate = DateTime.Now,
                    ModifiedDate = DateTime.Now
                });
            return mock;
        }
        private Mock<IRoleService> InitMockForCreate()
        {
            var mock = new Mock<IRoleService>();
            mock.Setup(x => x.Insert(roleViewModel.Adapt(new RoleViewModel())));
            return mock;
        }
        private Mock<IRoleService> InitMockForDelete()
        {
            var mock = new Mock<IRoleService>();
            mock.Setup(x => x.Delete(10000));
            return mock;
        }

        private Mock<IRoleService> InitMockForList()
        {
            var list = GetList();
            var mock = new Mock<IRoleService>();
            mock
                .Setup(x => x.GetAll())
                .Returns(list);
            return mock;
        }
    }
}
