﻿using DatosysSmpl.Api.Controllers;
using DatosysSmpl.Service.Abstract;
using DatosysSmpl.Service.Model;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Collections.Generic;
using Microsoft.Extensions.DependencyInjection;
using System.Text;
using Xunit;
using Mapster;
using DatosysSmpl.Data.Entities;
using DatosysSmpl.Web.Enum;

namespace DatosysSmpl.Test.DatosysApiTests
{
    public class CourseTests : TestBase
    {
        private CourseController _controller;
        private ICourseService _service;
        private IPersonService _personService;
        private long personId;
        public CourseTests()
        {
            _service = Services.GetService<ICourseService>();
            _personService = Services.GetService<IPersonService>();
            personId = _personService.GetAll().LastOrDefault(p => p.Role.RoleName==RoleType.Teacher.ToString()).Id;
        }


        [Fact]
        public void CrudFullTest()
        {
            //ListPage
            Assert.NotNull(_service);
            _controller = GetController(_service);
            var result = _controller.GetAll();
            var objectResult = result as OkObjectResult;
            var data = objectResult;
            var res = (IEnumerable<CourseServiceModel>)data.Value;
            Assert.NotNull(res);
            //Create New 
            var newModel = new CourseServiceModel
            {
                ClassName = "test",
                TeacherId = personId
            };
            result = _controller.Insert(newModel);
            var okResult = result as OkResult;
            Assert.NotNull(okResult);
            Assert.Equal(200, okResult.StatusCode);

            //get Added id
            newModel.Id = _service.GetAll().LastOrDefault().Id;

            //
            //Post CourseEdit
            newModel.ClassName = "CourseTest";
            TypeAdapterConfig<Person, Person>.NewConfig().Ignore(p => p.Courses);
            TypeAdapterConfig<Role, Role>.NewConfig().Ignore(p => p.Persons);
            result = _controller.Update(newModel);
            okResult = result as OkResult;
            Assert.NotNull(okResult);
            Assert.Equal(200, okResult.StatusCode);

            //
            //Post CourseDelete
            result = _controller.Delete(newModel.Id);
            okResult = result as OkResult;
            Assert.NotNull(okResult);
            Assert.Equal(200, okResult.StatusCode);
            ////
        }

        private CourseController GetController(ICourseService _service)
        {
            var _controller = new CourseController(_service);
            return _controller;
        }

    }
}
