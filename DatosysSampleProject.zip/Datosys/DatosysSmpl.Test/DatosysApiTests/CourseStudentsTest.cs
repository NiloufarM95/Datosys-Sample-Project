﻿using DatosysSmpl.Api.Controllers;
using DatosysSmpl.Service.Abstract;
using DatosysSmpl.Service.Model;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Collections.Generic;
using Microsoft.Extensions.DependencyInjection;
using System.Text;
using Xunit;
using Mapster;
using DatosysSmpl.Data.Entities;
using DatosysSmpl.Web.Enum;

namespace DatosysSmpl.Test.DatosysApiTests
{
    public class CourseStudentsTests : TestBase
    {
        private CourseStudentsController _controller;
        private ICourseStudentsService _service;
        private IPersonService _personService;
        private ICourseService _courseService;
        private long personId;
        private long courseId;
        public CourseStudentsTests()
        {
            _service = Services.GetService<ICourseStudentsService>();
            _personService = Services.GetService<IPersonService>();
            personId = _personService.GetAll().LastOrDefault(p => p.Role.RoleName == RoleType.Student.ToString()).Id;
            _courseService = Services.GetService<ICourseService>();
            courseId = _courseService.GetAll().LastOrDefault().Id;
        }


        [Fact]
        public void CrudFullTest()
        {
            //ListPage
            Assert.NotNull(_service);
            _controller = GetController(_service);
            var result = _controller.GetAll();
            var objectResult = result as OkObjectResult;
            var data = objectResult;
            var res = (IEnumerable<CourseStudentsServiceModel>)data.Value;
            Assert.NotNull(res);
            //Create New 
            var newModel = new CourseStudentsServiceModel
            {
                StudentId = personId,
                GPA = 2.5,
                CourseId = courseId
            };
            result = _controller.Insert(newModel);
            var okResult = result as OkResult;
            Assert.NotNull(okResult);
            Assert.Equal(200, okResult.StatusCode);

            //get Added id
            TypeAdapterConfig<Person, PersonServiceModel>.NewConfig().Ignore(p => p.CourseStudents).Ignore(p => p.Courses);
            TypeAdapterConfig<Course, CourseServiceModel>.NewConfig().Ignore(p => p.CourseStudents);
            TypeAdapterConfig<Role, RoleServiceModel>.NewConfig().Ignore(p => p.Persons);
            newModel.Id = _service.GetAll().LastOrDefault().Id;

            //
            //Post CourseStudentsEdit
            newModel.GPA = 1.6;
            TypeAdapterConfig<Person, Person>.NewConfig().Ignore(p => p.CourseStudents).Ignore(p=>p.Courses);
            TypeAdapterConfig<Role, Role>.NewConfig().Ignore(p => p.Persons);
            TypeAdapterConfig<Course, Course>.NewConfig().Ignore(p => p.CourseStudents);
            result = _controller.Update(newModel);
            okResult = result as OkResult;
            Assert.NotNull(okResult);
            Assert.Equal(200, okResult.StatusCode);

            //
            //Post CourseStudentsDelete
            result = _controller.Delete(newModel.Id);
            okResult = result as OkResult;
            Assert.NotNull(okResult);
            Assert.Equal(200, okResult.StatusCode);
            ////
        }

        private CourseStudentsController GetController(ICourseStudentsService _service)
        {
            var _controller = new CourseStudentsController(_service);
            return _controller;
        }

    }
}
