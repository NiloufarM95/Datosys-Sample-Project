﻿using DatosysSmpl.Api.Controllers;
using DatosysSmpl.Service.Abstract;
using DatosysSmpl.Service.Model;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Collections.Generic;
using Microsoft.Extensions.DependencyInjection;
using System.Text;
using Xunit;
using Mapster;
using DatosysSmpl.Data.Entities;

namespace DatosysSmpl.Test.DatosysApiTests
{
    public class PersonTests : TestBase
    {
        private PersonController _controller;
        private IPersonService _service;
        private IRoleService _roleService;
        private long roleId;
        public PersonTests()
        {
            _service = Services.GetService<IPersonService>();
            _roleService= Services.GetService<IRoleService>();
            roleId = _roleService.GetAll().LastOrDefault().Id;
        }


        [Fact]
        public void CrudFullTest()
        {
            //ListPage
            Assert.NotNull(_service);
            _controller = GetController(_service);
            var result = _controller.GetAll();
            var objectResult = result as OkObjectResult;
            var data = objectResult;
            var res = (IEnumerable<PersonServiceModel>)data.Value;
            Assert.NotNull(res);
            //Create New 
            var newModel = new PersonServiceModel
            {
                FirstName = "test",
                LastName = "test",
                BirthDate = DateTime.Now,
                RoleId = roleId
            };
            result = _controller.Insert(newModel);
            var okResult = result as OkResult;
            Assert.NotNull(okResult);
            Assert.Equal(200, okResult.StatusCode);

            //get Added id
            newModel.Id = _service.GetAll().LastOrDefault().Id;

            //
            //Post PersonEdit
            newModel.FirstName = "PersonTest";
            TypeAdapterConfig<Role, Role>.NewConfig().Ignore(p => p.Persons);
            result = _controller.Update(newModel);
            okResult = result as OkResult;
            Assert.NotNull(okResult);
            Assert.Equal(200, okResult.StatusCode);

            //
            //Post PersonDelete
            result = _controller.Delete(newModel.Id);
            okResult = result as OkResult;
            Assert.NotNull(okResult);
            Assert.Equal(200, okResult.StatusCode);
            ////
        }

        private PersonController GetController(IPersonService _service)
        {
            var _controller = new PersonController(_service);
            return _controller;
        }

    }
}
