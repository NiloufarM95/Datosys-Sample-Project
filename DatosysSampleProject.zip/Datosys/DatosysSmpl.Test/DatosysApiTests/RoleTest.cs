﻿using DatosysSmpl.Api.Controllers;
using DatosysSmpl.Service.Abstract;
using DatosysSmpl.Service.Model;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Collections.Generic;
using Microsoft.Extensions.DependencyInjection;
using System.Text;
using Xunit;

namespace DatosysSmpl.Test.DatosysApiTests
{
    public class RoleTests : TestBase
    {
        private RoleController _controller;
        private IRoleService _service;
        public RoleTests()
        {
            _service = Services.GetService<IRoleService>();
        }


        [Fact]
        public void CrudFullTest()
        {
            //ListPage
            Assert.NotNull(_service);
            _controller = GetController(_service);
            var result = _controller.GetAll();
            var objectResult = result as OkObjectResult;
            var data = objectResult;
            var res = (IEnumerable<RoleServiceModel>)data.Value;
            Assert.NotNull(res);
            //Create New 
            var newModel = new RoleServiceModel
            {
                RoleName = "NewRole",
            };
            result = _controller.Insert(newModel);
            var okResult = result as OkResult;
            Assert.NotNull(okResult);
            Assert.Equal(200, okResult.StatusCode);

            //get Added id
            newModel.Id = _service.GetAll().ToList().LastOrDefault().Id;

            //
            //Post RoleEdit
            newModel.RoleName = "RoleTest";
            result = _controller.Update(newModel);
            okResult = result as OkResult;
            Assert.NotNull(okResult);
            Assert.Equal(200, okResult.StatusCode);

            //
            //Post RoleDelete
            result = _controller.Delete(newModel.Id);
            okResult = result as OkResult;
            Assert.NotNull(okResult);
            Assert.Equal(200, okResult.StatusCode);
            ////
        }

        private RoleController GetController(IRoleService _service)
        {
            var _controller = new RoleController(_service);
            return _controller;
        }

    }
}
