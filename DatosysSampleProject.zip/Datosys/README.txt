﻿Hi

At first, please run InitDataBase in BaseInfoMockTest.cs for creating required database. Then, right click on the solution --> Properties --> StartUp Project --> Multiple startup project; and select Api project and Web project. Finally, run the project!

Good luck :)