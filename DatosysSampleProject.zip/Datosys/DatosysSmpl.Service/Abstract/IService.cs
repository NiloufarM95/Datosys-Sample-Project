﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using DatosysSmpl.Data.Entities;
using DatosysSmpl.Service.Model;

namespace DatosysSmpl.Service.Abstract
{
    public interface IService<TInput, TResult>
        where TInput : BaseEntity
        where TResult : BaseServiceModel
    {
        IEnumerable<TResult> GetAll();
        TResult Get(long id);
        void Insert(TResult model);
        void Update(TResult model);
        void Delete(long id);
    }
}
