﻿using System;
using System.Collections.Generic;
using System.Text;
using DatosysSmpl.Data.Entities;
using DatosysSmpl.Service.Model;

namespace DatosysSmpl.Service.Abstract
{
    public interface ICourseService : IService<Course, CourseServiceModel>
    {
    }
}
