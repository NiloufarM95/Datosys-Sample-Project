﻿using System;
using System.Collections.Generic;
using System.Text;
using DatosysSmpl.Data.Entities;
using DatosysSmpl.Repository.Abstract;
using DatosysSmpl.Service.Abstract;
using DatosysSmpl.Service.Model;

namespace DatosysSmpl.Service.Concrete
{
    public class RoleService : Service<Role, RoleServiceModel>, IRoleService
    {
        public IRoleRepository RoleRepository { get; set; }
        public RoleService(IRoleRepository roleRepository):base(roleRepository)
        {
            this.RoleRepository = roleRepository;
        }
    }
}
