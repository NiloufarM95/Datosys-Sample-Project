﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using DatosysSmpl.Data.Entities;
using DatosysSmpl.Repository.Abstract;
using DatosysSmpl.Service.Abstract;
using DatosysSmpl.Service.Model;
using Mapster;

namespace DatosysSmpl.Service.Concrete
{
    public class Service<TInput, TResult> : IService<TInput, TResult>

        where TResult : BaseServiceModel
        where TInput : BaseEntity
    {
        private readonly IRepository<TInput> _repository;

        public Service(IRepository<TInput> repository)
        {
            _repository = repository;
        }

        public virtual IEnumerable<TResult> GetAll()
        {
            return _repository.GetAll().ToList().Adapt<IEnumerable<TResult>>();
        }

        public virtual TResult Get(long id)
        {
            return _repository.Get(id).Adapt<TResult>();

        }

        public virtual void Insert(TResult serviceModel)
        {
            _repository.Insert(serviceModel.Adapt<TInput>());
        }

        public virtual void Update(TResult serviceModel)
        {
            var props = typeof(TResult).GetProperties().Where(p => p.GetGetMethod().IsVirtual).Select(p => p.Name).ToArray();
            TypeAdapterConfig<TResult, TInput>.NewConfig()
                .Ignore(props)
                .Ignore(p => p.AddedDate)
                .Map(p => p.ModifiedDate, s => DateTime.Now);

            TypeAdapterConfig<TInput, TInput>.NewConfig()
                .Ignore(props)
                .Ignore(p => p.AddedDate)
                .Map(p => p.ModifiedDate, s => DateTime.Now);

            var model = _repository.Get(serviceModel.Id);
            var mapedEntity = serviceModel.Adapt(model);

            var m = mapedEntity.Adapt<TInput>();
            _repository.Update(m);
        }

        public virtual void Delete(long id)
        {
            _repository.Delete(id);

        }
    }
}
