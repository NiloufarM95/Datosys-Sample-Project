﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DatosysSmpl.Data.Entities;
using DatosysSmpl.Repository.Abstract;
using DatosysSmpl.Service.Abstract;
using DatosysSmpl.Service.Model;
using Mapster;
using Microsoft.EntityFrameworkCore;

namespace DatosysSmpl.Service.Concrete
{
    public class PersonService : Service<Person, PersonServiceModel>, IPersonService
    {
        public IPersonRepository PersonRepository { get; set; }
        public PersonService(IPersonRepository personRepository) : base(personRepository)
        {
            this.PersonRepository = personRepository;
        }

        public override IEnumerable<PersonServiceModel> GetAll()
        {
            var config=new TypeAdapterConfig();
            config.NewConfig<Role, RoleServiceModel>().Ignore(p => p.Persons);
            return PersonRepository.GetAll().Include(p=>p.Role).ToList().Adapt<IEnumerable<PersonServiceModel>>(config);
        }
    }
}
