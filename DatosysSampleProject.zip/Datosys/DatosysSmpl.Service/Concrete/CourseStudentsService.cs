﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DatosysSmpl.Data.Entities;
using DatosysSmpl.Repository.Abstract;
using DatosysSmpl.Service.Abstract;
using DatosysSmpl.Service.Model;
using Mapster;
using Microsoft.EntityFrameworkCore;

namespace DatosysSmpl.Service.Concrete
{
    public class CourseStudentsService : Service<CourseStudents, CourseStudentsServiceModel>, ICourseStudentsService
    {
        public ICourseStudentsRepository CourseStudentsRepository { get; set; }
        public CourseStudentsService(ICourseStudentsRepository courseStudentsRepository) : base(courseStudentsRepository)
        {
            this.CourseStudentsRepository = courseStudentsRepository;
        }

        public CourseStudentsPageServiceModel GetAllCourses(long courseId)
        {
            var config=new TypeAdapterConfig();
            config.NewConfig<Course, CourseServiceModel>().Ignore(p => p.CourseStudents);
            config.NewConfig<Person, PersonServiceModel>().Ignore(p => p.CourseStudents);
            var list = CourseStudentsRepository.GetBy(p => p.CourseId == courseId)
                .Include(p => p.Course)
                .Include(p => p.Student)
                .ToList()
                .Adapt<List<CourseStudents>, List<CourseStudentsServiceModel>>(config);
            var model = new CourseStudentsPageServiceModel
            {
                CourseStudents = list,
                CourseStudent = new CourseStudentsServiceModel
                {
                    CourseId = courseId
                }
            };
            return model;
        }

        public CourseStudentsServiceModel GetCourseStudent(long id, long courseId)
        {
            var config = new TypeAdapterConfig();
            config.NewConfig<Course, CourseServiceModel>().Ignore(p => p.CourseStudents);
            config.NewConfig<Person, PersonServiceModel>().Ignore(p => p.CourseStudents);
            var model = CourseStudentsRepository.GetBy(p => p.Id == id && p.CourseId == courseId)
                .Include(p => p.Course)
                .Include(p => p.Student)
                .Single().Adapt<CourseStudents,CourseStudentsServiceModel>(config);
            return model;
        }
    }
}
