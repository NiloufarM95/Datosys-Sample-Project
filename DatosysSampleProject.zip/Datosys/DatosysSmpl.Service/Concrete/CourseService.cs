﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DatosysSmpl.Data.Entities;
using DatosysSmpl.Repository.Abstract;
using DatosysSmpl.Service.Abstract;
using DatosysSmpl.Service.Model;
using Mapster;
using Microsoft.EntityFrameworkCore;

namespace DatosysSmpl.Service.Concrete
{
    public class CourseService : Service<Course, CourseServiceModel>, ICourseService
    {
        public ICourseRepository CourseRepository { get; set; }
        public CourseService(ICourseRepository courseRepository) : base(courseRepository)
        {
            this.CourseRepository = courseRepository;
        }

        public override IEnumerable<CourseServiceModel> GetAll()
        {
            var config = new TypeAdapterConfig();
            config.NewConfig<Person,PersonServiceModel>().Ignore(p => p.Courses);
            config.NewConfig<Role, RoleServiceModel>().Ignore(p => p.Persons);
            return CourseRepository.GetAll().Include(p=>p.Teacher).ToList().Adapt<IEnumerable<CourseServiceModel>>(config);
        }
    }
}
