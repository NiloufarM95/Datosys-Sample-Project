﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DatosysSmpl.Service.Model
{
    public class RoleServiceModel:BaseServiceModel
    {
        public string RoleName { get; set; }
        public virtual ICollection<PersonServiceModel> Persons { get; set; }
    }
}
