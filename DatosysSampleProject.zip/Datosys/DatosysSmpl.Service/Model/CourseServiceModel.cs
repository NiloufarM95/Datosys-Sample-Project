﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DatosysSmpl.Service.Model
{
    public class CourseServiceModel:BaseServiceModel
    {
        public string ClassName { get; set; }
        public string Location { get; set; }
        public PersonServiceModel Teacher { get; set; }
        public long TeacherId { get; set; }
        public virtual ICollection<CourseStudentsServiceModel> CourseStudents { get; set; }
    }
}
