﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DatosysSmpl.Service.Model
{
    public class CourseStudentsServiceModel:BaseServiceModel
    {
        public PersonServiceModel Student { get; set; }
        public long StudentId { get; set; }
        public CourseServiceModel Course { get; set; }
        public long CourseId { get; set; }
        public double GPA { get; set; }
    }

    public class CourseStudentsPageServiceModel
    {
        public CourseStudentsServiceModel CourseStudent { get; set; }
        public List<CourseStudentsServiceModel> CourseStudents { get; set; }
    }
}
