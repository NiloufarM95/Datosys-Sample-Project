﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DatosysSmpl.Service.Model
{
    public class BaseServiceModel
    {
        public long Id { get; set; }
        public DateTime AddedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
