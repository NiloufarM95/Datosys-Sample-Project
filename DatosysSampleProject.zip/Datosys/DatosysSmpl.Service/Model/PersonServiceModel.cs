﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DatosysSmpl.Service.Model
{
    public class PersonServiceModel:BaseServiceModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime BirthDate { get; set; }
        public RoleServiceModel Role { get; set; }
        public long RoleId { get; set; }
        public virtual ICollection<CourseStudentsServiceModel> CourseStudents { get; set; }
        public virtual ICollection<CourseServiceModel> Courses { get; set; }
    }
}
