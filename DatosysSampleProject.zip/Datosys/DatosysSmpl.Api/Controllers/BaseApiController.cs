﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DatosysSmpl.Data.Entities;
using DatosysSmpl.Service.Abstract;
using DatosysSmpl.Service.Model;
using Microsoft.AspNetCore.Mvc;

namespace DatosysSmpl.Api.Controllers
{
    public class BaseApiController<TInput, TResult> : Controller
        where TInput : BaseEntity
        where TResult : BaseServiceModel
    {
        private readonly IService<TInput, TResult> _Service;
        public BaseApiController(IService<TInput, TResult> service)
        {
            _Service = service;
        }

        [HttpGet]
        public virtual IActionResult GetAll()
        {
            var list = _Service.GetAll();

            return Ok(list);
        }

        [HttpGet]
        public virtual IActionResult Get(long id)
        {
            var model = _Service.Get(id);
            return Ok(model);
        }

        [HttpPost]
        public virtual IActionResult Insert([FromBody] TResult model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _Service.Insert(model);
                    return Ok();
                }
                else
                {
                    return StatusCode(406, ModelState.Keys.ToString());//Not Acceptable
                }
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        [HttpPost]
        public virtual IActionResult Update([FromBody]TResult model)
        {
            try
            {
                _Service.Update(model);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }

        [HttpGet]
        public virtual IActionResult Delete(long id)
        {
            try
            {
                _Service.Delete(id);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest();
            }
        }
    }
}
