﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DatosysSmpl.Data.Entities;
using DatosysSmpl.Service.Abstract;
using DatosysSmpl.Service.Model;
using Microsoft.AspNetCore.Mvc;

namespace DatosysSmpl.Api.Controllers
{
    public class RoleController : BaseApiController<Role, RoleServiceModel>
    {
        public IRoleService RoleService { get; set; }

        public RoleController(IRoleService roleService) : base(roleService)
        {
            RoleService = roleService;
        }
        
    }
}