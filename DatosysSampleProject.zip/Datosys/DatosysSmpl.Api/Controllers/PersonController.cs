﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DatosysSmpl.Data.Entities;
using DatosysSmpl.Service.Abstract;
using DatosysSmpl.Service.Model;
using Microsoft.AspNetCore.Mvc;

namespace DatosysSmpl.Api.Controllers
{
    public class PersonController : BaseApiController<Person, PersonServiceModel>
    {
        public IPersonService PersonService { get; set; }

        public PersonController(IPersonService personService) : base(personService)
        {
            PersonService = personService;
        }

    }
}