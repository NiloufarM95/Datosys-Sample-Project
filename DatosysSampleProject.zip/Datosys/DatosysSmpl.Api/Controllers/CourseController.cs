﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DatosysSmpl.Data.Entities;
using DatosysSmpl.Service.Abstract;
using DatosysSmpl.Service.Model;
using Microsoft.AspNetCore.Mvc;

namespace DatosysSmpl.Api.Controllers
{
    public class CourseController : BaseApiController<Course, CourseServiceModel>
    {
        public ICourseService CourseService { get; set; }

        public CourseController(ICourseService courseService) : base(courseService)
        {
            CourseService = courseService;
        }
    }
}