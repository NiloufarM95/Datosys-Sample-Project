﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DatosysSmpl.Data.Entities;
using DatosysSmpl.Service.Abstract;
using DatosysSmpl.Service.Model;
using Microsoft.AspNetCore.Mvc;

namespace DatosysSmpl.Api.Controllers
{
    public class CourseStudentsController : BaseApiController<CourseStudents, CourseStudentsServiceModel>
    {
        public ICourseStudentsService CourseStudentsService { get; set; }

        public CourseStudentsController(ICourseStudentsService courseStudentsService) : base(courseStudentsService)
        {
            CourseStudentsService = courseStudentsService;
        }

        public IActionResult GetAllCourses(long courseId)
        {
            var list = CourseStudentsService.GetAllCourses(courseId);

            return Ok(list);
        }

        public IActionResult GetCourseStudent(long id, long courseId)
        {
            var model = CourseStudentsService.GetCourseStudent(id,courseId);
            return Ok(model);
        }
    }
}