﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DatosysSmpl.Web
{
    public class AppSetting
    {
        public string DatosysSmplUri { get; set; }
    }
}
