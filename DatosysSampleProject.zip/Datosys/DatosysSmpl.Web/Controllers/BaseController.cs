﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DatosysSmpl.Service.Model;
using DatosysSmpl.Web.Enum;
using DatosysSmpl.Web.Models;
using DatosysSmpl.Web.Service;
using Mapster;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace DatosysSmpl.Web.Controllers
{
    public class BaseController : Controller
    {
        public IRoleService _roleService { get; set; }
        public IPersonService _personService { get; set; }
        public ICourseService _courseService { get; set; }
        public ICourseStudentsService _courseStudentsService { get; set; }
        public BaseController(IRoleService roleService, IPersonService personService, ICourseService courseService, ICourseStudentsService courseStudentsService)
        {
            _roleService = roleService;
            _personService = personService;
            _courseService = courseService;
            _courseStudentsService = courseStudentsService;
        }
        #region Role
        // GET: Role
        public ActionResult Role(string errorMessage = null)
        {
            var list = _roleService.GetAll();
            ViewBag.Error = errorMessage;
            return View(list);
        }

        // GET: Role/Create
        public ActionResult RoleCreate()
        {
            return View("RoleCreate");
        }

        // POST: Role/Create
        [HttpPost]
        public ActionResult RoleCreate(RoleViewModel roleViewModel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    // TODO: Add insert logic here
                    _roleService.Insert(roleViewModel);
                    return RedirectToAction(nameof(Role));
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Error");
            }
            return View();

        }

        // GET: Role/Edit/id
        public ActionResult RoleEdit(long id)
        {
            return View(_roleService.Get(id));
        }

        // POST: Role/Edit/id
        [HttpPost]
        public ActionResult RoleEdit(RoleViewModel roleViewModel)
        {
            try
            {
                _roleService.Update(roleViewModel);
                return RedirectToAction(nameof(Role));
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: Role/Delete/id
        public ActionResult RoleDelete(long id)
        {
            try
            {
                _roleService.Delete(id);
                return RedirectToAction(nameof(Role));
            }
            catch (Exception ex)
            {
                return RedirectToAction("Role", new { errorMessage = "Error" });
            }
        }
        #endregion

        #region Person
        // GET: Person
        public ActionResult Person(string errorMessage = null)
        {
            var list = _personService.GetAll();
            ViewBag.Error = errorMessage;
            return View(list);
        }

        // GET: Person/Create
        public ActionResult PersonCreate()
        {
            return View("PersonCreate");
        }

        // POST: Person/Create
        [HttpPost]
        public ActionResult PersonCreate(PersonViewModel personViewModel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    // TODO: Add insert logic here
                    _personService.Insert(personViewModel);
                    return RedirectToAction(nameof(Person));
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Error");
            }
            return View();

        }

        // GET: Person/Edit/id
        public ActionResult PersonEdit(long id)
        {
            var model = _personService.Get(id);
            return View(model);
        }

        // POST: Person/Edit/id
        [HttpPost]
        public ActionResult PersonEdit(PersonViewModel personViewModel)
        {
            try
            {
                _personService.Update(personViewModel);
                return RedirectToAction(nameof(Person));
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: Person/Delete/id
        public ActionResult PersonDelete(long id)
        {
            try
            {
                _personService.Delete(id);
                return RedirectToAction(nameof(Person));
            }
            catch (Exception ex)
            {
                return RedirectToAction("Person", new { errorMessage = "Error" });
            }
        }
        #endregion

        #region Course
        // GET: Course
        public ActionResult Course(string errorMessage = null)
        {
            var list = _courseService.GetAll();
            ViewBag.Error = errorMessage;
            return View(list);
        }

        // GET: Course/Create
        public ActionResult CourseCreate()
        {
            return View("CourseCreate");
        }

        // POST: Course/Create
        [HttpPost]
        public ActionResult CourseCreate(CourseViewModel courseViewModel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    // TODO: Add insert logic here
                    _courseService.Insert(courseViewModel);
                    return RedirectToAction(nameof(Course));
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Error");
            }
            return View();

        }

        // GET: Course/Edit/id
        public ActionResult CourseEdit(long id)
        {
            var model = _courseService.Get(id);
            return View(model);
        }

        // POST: Course/Edit/id
        [HttpPost]
        public ActionResult CourseEdit(CourseViewModel courseViewModel)
        {
            try
            {
                _courseService.Update(courseViewModel);
                return RedirectToAction(nameof(Course));
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: Course/Delete/id
        public ActionResult CourseDelete(long id)
        {
            try
            {
                _courseService.Delete(id);
                return RedirectToAction(nameof(Course));
            }
            catch (Exception ex)
            {
                return RedirectToAction("Course", new { errorMessage = "Error" });
            }
        }
        #endregion

        #region CourseStudents
        // GET: CourseStudents
        public ActionResult CourseStudents(long id,string errorMessage = null)
        {
            var list = _courseStudentsService.GetAllCourses(id);
            ViewBag.Error = errorMessage;
            return View(list);
        }

        // GET: CourseStudents/Create
        public ActionResult CourseStudentsCreate(long id)
        {
            var model=new CourseStudentsViewModel
            {
                CourseId = id
            };
            return View("CourseStudentsCreate",model);
        }

        // POST: CourseStudents/Create
        [HttpPost]
        public ActionResult CourseStudentsCreate(CourseStudentsViewModel courseStudentsViewModel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    // TODO: Add insert logic here
                    _courseStudentsService.Insert(courseStudentsViewModel);
                    return RedirectToAction(nameof(CourseStudents),new{id= courseStudentsViewModel .CourseId});
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Error");
            }
            return View();

        }

        // GET: CourseStudents/Edit/id
        public ActionResult CourseStudentsEdit(long id,long courseId)
        {
            var model = _courseStudentsService.GetCourseStudent(id, courseId);
            return View(model);
        }

        // POST: CourseStudents/Edit/id
        [HttpPost]
        public ActionResult CourseStudentsEdit(CourseStudentsViewModel courseStudentsViewModel)
        {
            try
            {
                _courseStudentsService.Update(courseStudentsViewModel);
                return RedirectToAction(nameof(CourseStudents), new { id = courseStudentsViewModel.CourseId });
            }
            catch (Exception ex)
            {
                return View();
            }
        }

        // GET: CourseStudents/Delete/id
        public ActionResult CourseStudentsDelete(long id,long courseId)
        {
            try
            {
                _courseStudentsService.Delete(id);
                return RedirectToAction(nameof(CourseStudents), new { id = courseId });
            }
            catch (Exception ex)
            {
                return RedirectToAction("CourseStudents", new { errorMessage = "Error",id = courseId });
            }
        }
        #endregion
    }
}