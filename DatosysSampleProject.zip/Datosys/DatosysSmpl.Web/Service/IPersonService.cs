﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DatosysSmpl.Web.Models;

namespace DatosysSmpl.Web.Service
{
    public interface IPersonService : IService<PersonViewModel>
    {
    }
}
