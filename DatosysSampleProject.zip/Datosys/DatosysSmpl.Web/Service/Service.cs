﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace DatosysSmpl.Web.Service
{
    public class Service<TViewModel> : IService<TViewModel>
    {
        public readonly IOptionsSnapshot<AppSetting> _settings;
        public readonly string _remoteServiceBaseUri;

        public Service(
            IOptionsSnapshot<AppSetting> settings)
        {
            _settings = settings;
            _remoteServiceBaseUri = $"{_settings.Value.DatosysSmplUri}/api";
        }

        public string Entity { get; set; }
        public string GetAllUri(string baseUri) => $"{baseUri}/{Entity}/GetAll";
        public string GetUri(string baseUri, long id) => $"{baseUri}/{Entity}/Get/{id}";
        public string DeleteUri(string baseUri, long id) => $"{baseUri}/{Entity}/Delete/{id}";
        public string InsertUri(string baseUri) => $"{baseUri}/{Entity}/Insert";
        public string UpdateUri(string baseUri) => $"{baseUri}/{Entity}/Update";

        public virtual List<TViewModel> GetAll()
        {
            var uri = GetAllUri(_remoteServiceBaseUri);
            using (var httpClient = new HttpClient())
            {
                var dataString = httpClient.GetStringAsync(uri).Result;
                var response = JsonConvert.DeserializeObject<List<TViewModel>>(dataString);
                return response;
            }
        }

        public TViewModel Get(long id)
        {
            var uri = GetUri(_remoteServiceBaseUri, id);
            using (var httpClient = new HttpClient())
            {
                var dataString = httpClient.GetStringAsync(uri).Result;
                var response = JsonConvert.DeserializeObject<TViewModel>(dataString);
                return response;
            }
        }

        public bool Insert(TViewModel model)
        {
            var uri = InsertUri(_remoteServiceBaseUri);
            var requestMessage = new HttpRequestMessage(HttpMethod.Post, uri);

            requestMessage.Content = new StringContent(JsonConvert.SerializeObject(model), System.Text.Encoding.UTF8, "application/json");
            using (var httpClient = new HttpClient())
            {
                var response = httpClient.PostAsync(uri, requestMessage.Content).Result;
                return response.IsSuccessStatusCode;
            }
        }
        public bool Update(TViewModel model)
        {
            var uri = UpdateUri(_remoteServiceBaseUri);
            var requestMessage = new HttpRequestMessage(HttpMethod.Post, uri);

            requestMessage.Content = new StringContent(JsonConvert.SerializeObject(model), System.Text.Encoding.UTF8, "application/json");
            using (var httpClient = new HttpClient())
            {
                var response = httpClient.PostAsync(uri, requestMessage.Content).Result;
                return response.IsSuccessStatusCode;
            }
        }
        public void Delete(long id)
        {
            var uri = DeleteUri(_remoteServiceBaseUri, id);
            using (var httpClient = new HttpClient())
            {
                var response = httpClient.GetStringAsync(uri).Result;
            }
        }
    }
}
