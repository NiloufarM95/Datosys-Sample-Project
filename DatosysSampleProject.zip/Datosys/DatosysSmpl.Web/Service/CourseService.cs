﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DatosysSmpl.Web.Models;
using Microsoft.Extensions.Options;

namespace DatosysSmpl.Web.Service
{
    public class CourseService : Service<CourseViewModel>, ICourseService
    {
        public CourseService(IOptionsSnapshot<AppSetting> settings) : base(settings)
        {
            base.Entity = "Course";
        }
    }
}
