﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DatosysSmpl.Web.Models;

namespace DatosysSmpl.Web.Service
{
    public interface ICourseStudentsService : IService<CourseStudentsViewModel>
    {
        CourseStudentsPageViewModel GetAllCourses(long courseId);
        CourseStudentsViewModel GetCourseStudent(long id, long courseId);
    }
}
