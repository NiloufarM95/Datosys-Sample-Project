﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DatosysSmpl.Web.Service
{
    public interface IService<TViewModel>
    {
        List<TViewModel> GetAll();
        TViewModel Get(long id);
        bool Insert(TViewModel model);
        bool Update(TViewModel model);
        void Delete(long id);
    }
}
