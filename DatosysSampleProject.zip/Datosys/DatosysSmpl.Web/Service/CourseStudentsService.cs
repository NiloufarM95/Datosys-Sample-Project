﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using DatosysSmpl.Web.Models;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace DatosysSmpl.Web.Service
{
    public class CourseStudentsService : Service<CourseStudentsViewModel>, ICourseStudentsService
    {
        public CourseStudentsService(IOptionsSnapshot<AppSetting> settings) : base(settings)
        {
            base.Entity = "CourseStudents";
        }
        public string GetAllCoursesUri(string baseUri,long courseId) => $"{baseUri}/{Entity}/GetAllCourses?courseId={courseId}";
        public CourseStudentsPageViewModel GetAllCourses(long courseId)
        {
                var uri = GetAllCoursesUri(_remoteServiceBaseUri,courseId);
            using (var httpClient = new HttpClient())
            {
                var dataString = httpClient.GetStringAsync(uri).Result;
                var response = JsonConvert.DeserializeObject<CourseStudentsPageViewModel>(dataString);
                return response;
            }
        }
        public string GetCourseStudentUri(string baseUri, long id, long courseId) => $"{baseUri}/{Entity}/Get/{id}?courseId={courseId}";
        public CourseStudentsViewModel GetCourseStudent(long id, long courseId)
        {
            var uri = GetCourseStudentUri(_remoteServiceBaseUri, id, courseId);
            using (var httpClient = new HttpClient())
            {
                var dataString = httpClient.GetStringAsync(uri).Result;
                var response = JsonConvert.DeserializeObject<CourseStudentsViewModel>(dataString);
                return response;
            }
        }
    }
}
