﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DatosysSmpl.Web.Models;
using Microsoft.Extensions.Options;

namespace DatosysSmpl.Web.Service
{
    public class PersonService : Service<PersonViewModel>, IPersonService
    {
        public PersonService(IOptionsSnapshot<AppSetting> settings) : base(settings)
        {
            base.Entity = "Person";
        }
    }
}
