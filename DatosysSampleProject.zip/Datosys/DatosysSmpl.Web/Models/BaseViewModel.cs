﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace DatosysSmpl.Web.Models
{
    public class BaseViewModel
    {
        public long Id { get; set; }
        public DateTime AddedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
    }

    public class RoleViewModel : BaseViewModel
    {
        public string RoleName { get; set; }
    }

    public class PersonViewModel : BaseViewModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime BirthDate { get; set; }
        public RoleViewModel Role { get; set; }
        public long RoleId { get; set; }
    }

    public class CourseViewModel : BaseViewModel
    {
        public string ClassName { get; set; }
        public string Location { get; set; }
        public PersonViewModel Teacher { get; set; }
        public long TeacherId { get; set; }
    }

    public class CourseStudentsViewModel : BaseViewModel
    {
        public PersonViewModel Student { get; set; }
        public long StudentId { get; set; }
        public CourseViewModel Course { get; set; }
        public long CourseId { get; set; }
        public decimal GPA { get; set; }
    }

    public class CourseStudentsPageViewModel
    {
        public CourseStudentsViewModel CourseStudent { get; set; }
        public List<CourseStudentsViewModel> CourseStudents{ get; set; }
    }
}
