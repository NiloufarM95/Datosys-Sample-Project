﻿using DatosysSmpl.Web.Service;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.TagHelpers;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.TagHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DatosysSmpl.Web.Extensions
{
    [HtmlTargetElement("options", Attributes = "asp-entity-name")]
    public class OptionTagHelper : TagHelper
    {
        public IRoleService _roleService { get; set; }
        public IPersonService _personService { get; set; }
        public OptionTagHelper(IHtmlGenerator generator, IRoleService roleService, IPersonService personService)
        {
            _roleService = roleService;
            _personService = personService;
            Generator = generator;
        }

        [HtmlAttributeNotBound]
        public IHtmlGenerator Generator { get; set; }
        [HtmlAttributeName("asp-entity-name")]
        public string EntityName { get; set; }
        [HtmlAttributeName("asp-showdefaultitem")]
        public bool ShowDefaultItem { get; set; }
        [HtmlAttributeName("asp-filter-role-name")]
        public string FilterRoleName { get; set; }
        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.SuppressOutput();
            object formDataEntry;
            context.Items.TryGetValue(typeof(SelectTagHelper), out formDataEntry);
            ICollection<string> selectedValues = null;
            var encodedValues = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (formDataEntry != null)
            {
                selectedValues = ((Microsoft.AspNetCore.Mvc.TagHelpers.Internal.CurrentValues)formDataEntry).Values;
                if (selectedValues != null && selectedValues.Count != 0)
                {
                    foreach (var selectedValue in selectedValues)
                    {
                        encodedValues.Add(Generator.Encode(selectedValue));
                    }
                }
            }
            var items = GetItems(FilterRoleName);
            if (items == null) return;

            if (ShowDefaultItem)
                output.Content.AppendHtml($"<option value=''>Please select</option>");

            foreach (var item in items)
            {
                var selected = (selectedValues != null && selectedValues.Contains(item.Value)) ||
                                encodedValues.Contains(item.Value);
                var selectedAttr = selected || item.Selected ? "selected='selected'" : "";

                output.Content.AppendHtml(item.Value != null
                    ? $"<option value='{item.Value}' {selectedAttr}>{item.Text}</option>"
                    : $"<option>{item.Text}</option>");
            }
        }
        private IEnumerable<SelectListItem> GetItems(string filterRoleName)
        {
            if (string.Equals(this.EntityName, "Role", StringComparison.OrdinalIgnoreCase))
                return _roleService.GetAll().Select(r => new SelectListItem() { Value = r.Id.ToString(), Text = r.RoleName });

            if (string.Equals(this.EntityName, "Person", StringComparison.OrdinalIgnoreCase))
                return _personService.GetAll().Where(p=>p.Role.RoleName== filterRoleName).Select(r => new SelectListItem() { Value = r.Id.ToString(), Text = r.FirstName+" "+r.LastName });
            return null;
        }
    }
}
