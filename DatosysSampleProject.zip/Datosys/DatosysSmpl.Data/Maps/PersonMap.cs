﻿using System;
using System.Collections.Generic;
using System.Text;
using DatosysSmpl.Data.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DatosysSmpl.Data.Maps
{
    public class PersonMap : BaseMap<Person>
    {
        public PersonMap(EntityTypeBuilder<Person> entityTypeBuilder) : base(entityTypeBuilder)
        {
            entityTypeBuilder.HasOne(p => p.Role)
                .WithMany(p => p.Persons)
                .HasForeignKey(p => p.RoleId)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
