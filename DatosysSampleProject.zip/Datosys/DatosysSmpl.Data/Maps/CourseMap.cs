﻿using System;
using System.Collections.Generic;
using System.Text;
using DatosysSmpl.Data.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DatosysSmpl.Data.Maps
{
    public class CourseMap : BaseMap<Course>
    {
        public CourseMap(EntityTypeBuilder<Course> entityTypeBuilder) : base(entityTypeBuilder)
        {
            entityTypeBuilder.HasOne(p => p.Teacher)
                .WithMany(p => p.Courses)
                .HasForeignKey(p => p.TeacherId)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
