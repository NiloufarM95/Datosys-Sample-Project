﻿using System;
using System.Collections.Generic;
using System.Text;
using DatosysSmpl.Data.Entities;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DatosysSmpl.Data.Maps
{
    public class RoleMap:BaseMap<Role>
    {
        public RoleMap(EntityTypeBuilder<Role> entityTypeBuilder):base(entityTypeBuilder)
        {
                
        }
    }
}
