﻿using System;
using System.Collections.Generic;
using System.Text;
using DatosysSmpl.Data.Entities;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DatosysSmpl.Data.Maps
{
    public class BaseMap<T> where T : BaseEntity
    {
        public BaseMap(EntityTypeBuilder<T> entityBuilder)
        {
            entityBuilder.HasKey(t => t.Id);
        }
    }
}
