﻿using System;
using System.Collections.Generic;
using System.Text;
using DatosysSmpl.Data.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DatosysSmpl.Data.Maps
{
    public class CourseStudentsMap : BaseMap<CourseStudents>
    {
        public CourseStudentsMap(EntityTypeBuilder<CourseStudents> entityTypeBuilder) : base(entityTypeBuilder)
        {
            entityTypeBuilder.HasOne(p => p.Course)
                .WithMany(p => p.CourseStudents)
                .HasForeignKey(p => p.CourseId)
                .OnDelete(DeleteBehavior.Restrict);

            entityTypeBuilder.HasOne(p => p.Student)
                .WithMany(p => p.CourseStudents)
                .HasForeignKey(p => p.StudentId)
                .OnDelete(DeleteBehavior.Restrict);

            entityTypeBuilder.HasIndex(p=>new {p.CourseId,p.StudentId}).IsUnique();
        }
    }
}
