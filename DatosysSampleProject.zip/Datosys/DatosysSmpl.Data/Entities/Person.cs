﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DatosysSmpl.Data.Entities
{
    public class Person:BaseEntity
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime BirthDate { get; set; }
        public Role Role { get; set; }
        public long RoleId { get; set; }
        public virtual ICollection<CourseStudents> CourseStudents { get; set; }
        public virtual ICollection<Course> Courses { get; set; }
    }
}
