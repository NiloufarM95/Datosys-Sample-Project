﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DatosysSmpl.Data.Entities
{
    public class CourseStudents:BaseEntity
    {
        public Person Student { get; set; }
        public long StudentId { get; set; }
        public Course Course { get; set; }
        public long CourseId { get; set; }
        public double GPA { get; set; }
    }
}
