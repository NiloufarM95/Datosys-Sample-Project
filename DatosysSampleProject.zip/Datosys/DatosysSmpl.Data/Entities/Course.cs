﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DatosysSmpl.Data.Entities
{
    public class Course : BaseEntity
    {
        public string ClassName { get; set; }
        public string Location { get; set; }
        public Person Teacher { get; set; }
        public long TeacherId { get; set; }
        public virtual ICollection<CourseStudents> CourseStudents { get; set; }
    }
}
