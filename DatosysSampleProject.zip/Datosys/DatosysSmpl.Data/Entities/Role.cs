﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DatosysSmpl.Data.Entities
{
    public class Role:BaseEntity
    {
        public string RoleName { get; set; }
        public virtual ICollection<Person> Persons { get; set; }
    }
}
